<?php 
    class Sites extends QueryBuilder {
        public function __construct() {
            
            $this->table = 'sites';
        }
    }
?>