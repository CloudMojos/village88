<?php 
    class Clients extends QueryBuilder {
        public function __construct() {
            
            $this->table = 'clients';
        }
    }
?>