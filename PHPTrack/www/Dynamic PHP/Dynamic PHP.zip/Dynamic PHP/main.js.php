<?php 
    $yes = rand(100, 1000);
?>
$(document).ready(function(){
  console.log("You are <?= $yes ?>x better than before!");
});
