<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="main.css.php">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="main.js.php"></script>
    <title>Document</title>
</head>
<body>
    <p>This text changes its size every reload.</p>
    <em>Thanks to PHP that generated a CSS File!</em>

    <img src="img.php" alt="">
    <img src="img.php" alt="">
    <img src="img.php" alt="">
    <img src="img.php" alt="">
    <img src="img.php" alt="">
</body>
</html>