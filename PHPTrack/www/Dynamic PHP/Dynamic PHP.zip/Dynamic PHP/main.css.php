<?php 
    header('Content-type: text/css');

    $font_size = rand(14, 25);
?>

p { 
    font-size: <?= $font_size ?>px; 
}
em { 
    font-size: <?= $font_size ?>px; 
}