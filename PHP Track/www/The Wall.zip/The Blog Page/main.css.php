<?php header('Content-type: text/css'); ?>


body {
    .banner {
        min-width: 100vw;
        max-height: 50vh;
        object-fit: cover;
        object-position: 0% 80%;
    }
}